
/* Unsupported Browser Alert*/
var cgBrowserAlert = "Tu navegador no soporta los requisitos necesarios para mostrar las preguntas correctamente.";

/* TextEntry 2 Feedback text */
var cgTextEntry2Response = "Tu respondiste: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ";

/* Gappfill 2 Feedback text */
/* e.g. (You got = cgGapfill2Response1) x (out of = cgGapfill2Response2) y (correct = cgGapfill2Response3)*/
var cgGapfill2Response1= "Tuviste ";
var cgGapfill2Response2 = " correctas de ";
var cgGapfill2Response3 = ".";

/* Gappfill 4 Feedback text */
/* e.g. (You got = cgGapfill4Response1) x (out of = cgGapfill4Response2) y (correct = cgGapfill4Response3)*/
var cgGapfill4Response1= "Tuviste ";
var cgGapfill4Response2 = " correctas de ";
var cgGapfill4Response3 = ".";

